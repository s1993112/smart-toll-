@extends('layouts.app.app')

@section('content')

    <section class="body-sign">
        <div class="center-sign">
            <a href="/" class="logo pull-left">
                <img src="{{asset('assets/images/logo.png')}}" height="54" alt="Porto Admin" />
            </a>

            <div class="panel panel-sign">
                <div class="panel-title-sign mt-xl text-right">
                    <h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> {{ __('Reset Password') }}</h2>
                </div>
                <div class="panel-body">
                    <div class="alert alert-info">
                        <p class="m-none text-semibold h6">Enter your e-mail below and we will send you reset instructions!</p>
                    </div>
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form method="POST" action="{{ route('password.email') }}">
                        @csrf
                        <div class="form-group mb-none">
                            <div class="input-group">
                                <input type="email"  placeholder="E-mail" class="form-control input-lg @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" />

                                <span class="input-group-btn">
										<button class="btn btn-primary btn-lg" type="submit">  {{ __('Reset') }}</button>
									</span>

                            </div>
                            @error('email')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>

                        <p class="text-center mt-lg">Remembered? <a href="{{route('login')}}">Sign In!</a>
                    </form>
                </div>
            </div>

            <p class="text-center text-muted mt-md mb-md">&copy; Copyright {{date('y')}}.</p>
        </div>
    </section>


@endsection
