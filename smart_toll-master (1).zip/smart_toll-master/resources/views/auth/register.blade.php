@extends('layouts.auth.auth')

@section('content')


    <section class="body-sign">
        <div class="center-sign">
            <a href="/" class="logo pull-left">
                <img src="{{asset('assets/images/logo.png')}}" height="54" alt="Porto Admin" />
            </a>

            <div class="panel panel-sign">
                <div class="panel-title-sign mt-xl text-right">
                    <h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Sign Up</h2>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route('register') }}" id="form"  class="form-horizontal">
                        @csrf
                        <div class="form-group mb-none ">
                            <div class="row">
                            <div class="col-sm-4 mb-lg @error('first_name') has-error @enderror">
                            <label>First Name</label>
                            <input type="text" class="form-control input-lg " name="first_name" value="{{ old('first_name') }}" />
                                @error('first_name')
                                <label for="" class="error">
                                    {{ $message }}
                                </label>
                                @enderror
                            </div>


                                <div class="col-sm-4 mb-lg  @error('middle_name') has-error @enderror">
                            <label>Middle Name</label>
                            <input name="middle_name" type="text" class="form-control input-lg" value="{{ old('middle_name') }} "/>

                                    @error('middle_name')
                                    <label for="" class="error">
                                        {{ $message }}
                                    </label>
                                    @enderror
                        </div>

                                <div class="col-sm-4 mb-lg">
                            <label>Last Name</label>
                            <input name="last_name" type="text" class="form-control input-lg @error('last_name') has-error @enderror"  value="{{ old('last_name') }}"/>
                                    @error('last_name')
                                    <label for="" class="error">
                                        {{ $message }}
                                    </label>
                                    @enderror
                        </div>

                        </div>

                        </div>

                        <div class="form-group mb-lg  @error('username') has-error @enderror">
                            <label>Username</label>
                            <input type="text" class="form-control input-lg" name="username" value="{{ old('username') }}" />
                            @error('username')
                            <label for="" class="error">
                                {{ $message }}
                            </label>
                            @enderror
                        </div>

                        <div class="form-group mb-lg @error('email') has-error @enderror">
                            <label>E-mail Address</label>
                            <input  type="email" class="form-control input-lg " name="email" value="{{ old('email') }}"/>
                            @error('email')
                            <label for="" class="error">
                                {{ $message }}
                            </label>
                            @enderror
                        </div>

                        <div class="form-group mb-lg @error('contact') has-error @enderror">
                            <label>Contact Number</label>
                            <input  type="text" class="form-control input-lg  " name="contact" value="{{ old('contact') }}" />
                            @error('contact')
                            <label for="" class="error">
                                {{ $message }}
                            </label>
                            @enderror
                        </div>
                        <div class="form-group mb-lg @error('nic') has-error @enderror">
                            <label>NIC</label>
                            <input  type="text" class="form-control input-lg  " name="nic" value="{{ old('nic') }}" />
                            @error('nic')
                            <label for="" class="error">
                                {{ $message }}
                            </label>
                            @enderror
                        </div>

                        <div class="form-group mb-none">
                            <div class="row">
                                <div class="col-sm-6 md-lg">
                                    <label>Building</label>
                                    <input name="building" type="text" class="form-control input-lg" value="{{ old('building') }}"/>
                                </div>
                                <div class="col-sm-6  mb-lg">
                                    <label>Street</label>
                                    <input name="street" type="text" class="form-control input-lg" value="{{ old('street') }}"/>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6  mb-lg">
                                    <label>Area</label>
                                    <input name="area" type="text" class="form-control input-lg" value="{{ old('area') }}"/>
                                </div>
                                <div class="col-sm-6 mb-lg">
                                    <label>Floor</label>
                                    <input name="floor" type="text" class="form-control input-lg" value="{{ old('floor') }}"/>
                                </div>

                            </div>

                        </div>

                        <div class="form-group mb-none @error('password') has-error @enderror">
                            <div class="row">
                                <div class="col-sm-6 mb-lg">
                                    <label>Password</label>
                                    <input name="password" type="password" class="form-control input-lg " />
                                    @error('password')
                                    <label for="" class="error">
                                        {{ $message }}
                                    </label>
                                    @enderror
                                </div>

                                <div class="col-sm-6 mb-lg">
                                    <label>Password Confirmation</label>
                                    <input name="password_confirmation" id="password-confirmation" type="password" class="form-control input-lg"/>
                                    @error('c_password')
                                    <label for="" class="error">
                                        {{ $message }}
                                    </label>
                                    @enderror
                                </div>

                            </div>
                        </div>

                        <div class="row">

                            <div class="col-sm-4 text-right">
                                <button type="submit" class="btn btn-primary hidden-xs">Sign Up</button>
                                <button type="submit" class="btn btn-primary btn-block btn-lg visible-xs mt-lg">Sign Up</button>
                            </div>
                        </div>


                        <p class="text-center">Already have an account? <a href="{{route('login')}}">Sign In!</a>

                    </form>
                </div>
            </div>

            <p class="text-center text-muted mt-md mb-md">&copy; Copyright {{date('Y')}}.</p>
        </div>
    </section>


@endsection
