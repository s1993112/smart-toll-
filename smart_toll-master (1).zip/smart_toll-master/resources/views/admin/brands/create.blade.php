@extends('layouts.app.app')
@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Car Types</h2>

            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{url('/')}}">
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Cars</span></li>
                    <li><span>Car Types</span></li>
                </ol>

                <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <!-- start: page -->
        <div class="row">
            <div class="col-md-12">
                <form id="form" method="post" action="{{route('brands.store')}}" class="form-horizontal">
                    <section class="panel">
                        <header class="panel-heading">


                            <h2 class="panel-title">Create Car Type</h2>

                        </header>
                        <div class="panel-body">
                            <div class="form-group">
                                @csrf
                                <label class="col-sm-3 control-label">Name <span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" value="{{ Request::old('name') ?: '' }}" class="form-control" placeholder="eg.: Hatchback"/>
                                    @if ($errors->has('name'))
                                        <span class="form-text text-muted">{{ $errors->first('name') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Status <span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <div class="radio-custom radio-primary">
                                        <input id="awesome" name="status" type="radio" value="1"  />
                                        <label for="awesome">Enable</label>
                                    </div>
                                    <div class="radio-custom radio-primary">
                                        <input id="very-awesome" name="status" type="radio" value="0" />
                                        <label for="Disable">Disable</label>
                                    </div>
                                    @if ($errors->has('status'))
                                        <span class="form-text text-muted">{{ $errors->first('status') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <footer class="panel-footer">
                            <div class="row">
                                <div class="col-sm-9 col-sm-offset-3">
                                    <button class="btn btn-primary">Submit</button>
                                    <button type="reset" class="btn btn-default">Reset</button>
                                </div>
                            </div>
                        </footer>
                    </section>
                </form>
            </div>

        </div>
        <!-- end: page -->
    </section>


@endsection
