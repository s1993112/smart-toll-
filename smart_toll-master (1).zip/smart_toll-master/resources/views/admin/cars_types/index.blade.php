@extends('layouts.app.app')
@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Advanced Tables</h2>

            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{url('/')}}">
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Cars</span></li>
                    <li><span>Car Types</span></li>
                </ol>

                <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>
    <section class="panel">
        @if (session()->has('success'))
               <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Successfull !</strong> {!! session()->get('success') !!}.
            </div>
        @endif
        <header class="panel-heading">
            <div class="panel-actions">
                <button type="button" onclick="window.location.href='{{route('cars_type.create')}}'" class="mb-xs mt-xs mr-xs btn btn-primary">Create</button>
                <button type="button" onclick="window.location.href='{{route('cars_type.mass_destroy')}}'" class="mb-xs mt-xs mr-xs btn btn-danger">Delete</button>

            </div>

            <h2 class="panel-title">Car Types</h2>
        </header>
        <div class="panel-body">
            <table class="table table-bordered table-striped mb-none" id="datatable-default">
                <thead>
                <tr>
                    <th></th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Updated At</th>

                </tr>
                </thead>
                <tbody>
                @foreach($car_types as $type)
                <tr class="gradeX">
                    <td><input type="checkbox" name="ids[]" value="{{$type->id}}"></td>
                    <td>{{$type->id}}</td>
                    <td>{{$type->name}}</td>
                    <td>{{($type->status)==1?'Enable':'Disable'}}</td>
                    <td>{{$type->created_at}}</td>
                    <td>{{$type->updated_at}}</td>
                </tr>
                @endforeach

                </tbody>
            </table>
        </div>
    </section>
    </section>
    @endsection
