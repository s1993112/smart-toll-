@extends('layouts.app.app')

@section('content')
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Car Types</h2>

            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a href="{{url('/')}}">
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Cars</span></li>
                    <li><span>Register Car</span></li>
                </ol>

                <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <!-- start: page -->
        <div class="row">
            <div class="col-md-12">
                <form id="form" method="post" action="{{route('cars.store')}}" class="form-horizontal">
                    <section class="panel">
                        <header class="panel-heading">


                            <h2 class="panel-title">Create Car Type</h2>

                        </header>
                        <div class="panel-body">
                            <div class="form-group">
                                @csrf
                                <label class="col-sm-3 control-label">Car Name <span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" value="{{ Request::old('name') ?: '' }}" class="form-control" placeholder="eg.: Mehran"/>
                                    @if ($errors->has('name'))
                                        <span class="form-text text-muted">{{ $errors->first('name') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Car Brand <span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <select data-plugin-selectTwo class="form-control populate" name="brand">
                                        @foreach($brands as $brand)
                                            <option value="{{$brand->id}}">{{$brand->name}}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('brand'))
                                        <span class="form-text text-muted">{{ $errors->first('brand') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Car Type <span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <select data-plugin-selectTwo class="form-control populate" name="type">
                                        @foreach($types as $type)
                                          <option value="{{$type->id}}">{{$type->name}}</option>
                                            @endforeach
                                    </select>

                                    @if ($errors->has('type'))
                                        <span class="form-text text-muted">{{ $errors->first('type') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">CC <span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="cc" value="{{ Request::old('cc"') ?: '' }}" class="form-control" placeholder="800"/>
                                    @if ($errors->has('cc"'))
                                        <span class="form-text text-muted">{{ $errors->first('cc"') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Chasis No<span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="chasis" value="{{ Request::old('chasis') ?: '' }}" class="form-control" placeholder="123456789"/>
                                    @if ($errors->has('chasis'))
                                        <span class="form-text text-muted">{{ $errors->first('chasis') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Registration Number<span class="required">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="registration" value="{{ Request::old('registration') ?: '' }}" class="form-control" placeholder="eg.: ABC-123"/>
                                    @if ($errors->has('registration'))
                                        <span class="form-text text-muted">{{ $errors->first('registration') }}</span>
                                    @endif
                                </div>
                            </div>


                        </div>
                        <footer class="panel-footer">
                            <div class="row">
                                <div class="col-sm-9 col-sm-offset-3">
                                    <button class="btn btn-primary">Submit</button>
                                    <button type="reset" class="btn btn-default">Reset</button>
                                </div>
                            </div>
                        </footer>
                    </section>
                </form>
            </div>

        </div>
        <!-- end: page -->
    </section>

@endsection
