<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');

});
    Route::group(['prefix' => 'admin','middleware' => 'auth','namespace' => 'Admin'],function(){
        Route::resource('dashboard','DashboardController');
        Route::resource('cars','CarsController');
        Route::resource('cars_type','CarTypesController');
        Route::resource('brands','BrandController');
        Route::post('cars_type/mass_destroy','CarTypesController@massdestroy')->name('cars_type.mass_destroy');
        Route::post('cars/mass_destroy','CarsController@massdestroy')->name('cars.mass_destroy');
        Route::post('brands/mass_destroy','BrandController@massdestroy')->name('brands.mass_destroy');
});

Auth::routes();
